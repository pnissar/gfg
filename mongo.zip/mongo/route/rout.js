import express from "express"
import sv from "../auth/sv.js"
const rout = express.Router();
rout.post('/u', sv);
export default rout;